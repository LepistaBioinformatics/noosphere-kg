# Example Text

Marie Curie, 7 November 1867 – 4 July 1934, was a Polish and naturalised-French
physicist and chemist who conducted pioneering research on radioactivity. She
was the first woman to win a Nobel Prize, the first person to win a Nobel Prize
twice, and the only person to win a Nobel Prize in two scientific fields. Her
husband, Pierre Curie, was a co-winner of her first Nobel Prize, making them the
first-ever married couple to win the Nobel Prize and launching the Curie family
legacy of five Nobel Prizes. She was, in 1906, the first woman to become a
professor at the University of Paris. Also, Robin Williams.
